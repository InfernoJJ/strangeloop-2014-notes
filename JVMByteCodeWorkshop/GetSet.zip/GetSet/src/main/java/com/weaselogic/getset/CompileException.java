package com.weaselogic.getset;

public class CompileException extends Exception {

    public CompileException() {
        // TODO Auto-generated constructor stub
    }

    public CompileException(String message) {
        super(message);
    }

    public CompileException(Throwable cause) {
        super(cause);
    }

    public CompileException(String message, Throwable cause) {
        super(message, cause);
    }

}
